package com.farmmanagementpro.helper;

public class CommonConstants {
    public static final String SHARED_PREFERENCES = "MySharedPref";
}
