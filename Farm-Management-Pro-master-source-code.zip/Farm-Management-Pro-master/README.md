# Farm Management Pro
 
 ## Description 
 This All in One Farm Management App is packed with features to help you manage all your farm from Farm Finance Management to Animals Management (Dairy, Beef Drystock, Sheep, Pigs, Horses, even your dogs), Crops management, Fields, Animal Treatments, Farm Tractor and Machinery Service History.
 
 ## Team Members

 - Yasith Wimukthi (Team Leader)- [@yasithwimukthi](https://www.linkedin.com/in/yasith-wimukthi-116307189/)
 - Shalitha Alahakoon - [@shalithaalahakoon](https://www.linkedin.com/in/shalitha-alahakoon-60051a212/)
 - Hiruni Arunoda - [@hiruniarunoda](https://www.linkedin.com/in/hirudumini/)
 - Sandun Dharmadasa - [@sandundharmadasa](https://www.linkedin.com/in/sandun-dharmadasa/)
